const products=[
{name:'Floral Midi Dress',price:1499,cat:'Women',image:'p1'},
{name:"Men's Casual Shirt",price:999,cat:'Men',image:'p2'},
{name:"Girls Party Dress",price:1299,cat:'Kids',image:'p3'},
{name:"Men's Hoodie",price:1199,cat:'Men',image:'p4'},
{name:'Classic Summer Dress',price:1399,cat:'Women',image:'p5'},
{name:'Urban Overshirt',price:1099,cat:'Men',image:'p6'},
{name:'Kids Festive Set',price:1249,cat:'Kids',image:'p7'},
{name:'Everyday Handbag',price:899,cat:'Accessories',image:'p8'}
];
let cart=JSON.parse(localStorage.getItem('ffg-cart')||'[]');
const grid=document.getElementById('productGrid');
function money(n){return '₹'+n.toLocaleString('en-IN')}
function render(filter='All',query=''){
 const q=query.trim().toLowerCase();
 const list=products.filter(p=>(filter==='All'||p.cat===filter)&&(!q||p.name.toLowerCase().includes(q)||p.cat.toLowerCase().includes(q)));
 grid.innerHTML=list.length?list.map((p,i)=>`<article class="product-card"><div class="product-image ${p.image}" role="img" aria-label="${p.name}"></div><div class="product-info"><small>${p.cat}</small><h3>${p.name}</h3><div class="price">${money(p.price)}</div><button class="add" data-index="${products.indexOf(p)}">Add to Cart</button></div></article>`).join(''):'<p style="grid-column:1/-1;text-align:center;color:#777">No products found. Try another search.</p>';
 document.querySelectorAll('.add').forEach(b=>b.addEventListener('click',()=>addToCart(+b.dataset.index)));
}
function addToCart(index){cart.push(index);saveCart();showToast(products[index].name+' added to cart');}
function saveCart(){localStorage.setItem('ffg-cart',JSON.stringify(cart));document.getElementById('cartCount').textContent=cart.length;renderCart()}
function renderCart(){const box=document.getElementById('cartItems');if(!cart.length){box.innerHTML='<p style="color:#777">Your cart is empty.</p>';document.getElementById('cartTotal').textContent='₹0';return}let total=0;box.innerHTML=cart.map((idx,i)=>{const p=products[idx];total+=p.price;return `<div class="cart-row"><span>${p.name}</span><span>${money(p.price)} <button class="remove" data-remove="${i}">remove</button></span></div>`}).join('');document.getElementById('cartTotal').textContent=money(total);document.querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>{cart.splice(+b.dataset.remove,1);saveCart()})}
function showToast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.classList.remove('show'),1800)}
function openModal(id){document.getElementById(id).classList.add('open');document.getElementById(id).setAttribute('aria-hidden','false')}
function closeModal(id){document.getElementById(id).classList.remove('open');document.getElementById(id).setAttribute('aria-hidden','true')}
document.querySelectorAll('.filter').forEach(b=>b.onclick=()=>{document.querySelectorAll('.filter').forEach(x=>x.classList.remove('active'));b.classList.add('active');render(b.dataset.filter)})
document.querySelectorAll('.category-card').forEach(b=>b.onclick=()=>{document.getElementById('shop').scrollIntoView();const f=b.dataset.category==='New Arrivals'?'All':b.dataset.category;document.querySelectorAll('.filter').forEach(x=>x.classList.toggle('active',x.dataset.filter===f));render(f)})
document.getElementById('searchBtn').onclick=()=>{openModal('searchModal');setTimeout(()=>document.getElementById('searchInput').focus(),50)};
document.getElementById('searchInput').oninput=e=>{render('All',e.target.value);document.getElementById('searchHint').textContent='Showing matching products below.'};
document.getElementById('cartBtn').onclick=()=>openModal('cartModal');
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>closeModal(b.dataset.close));
document.querySelectorAll('.modal').forEach(m=>m.onclick=e=>{if(e.target===m)m.classList.remove('open')});
document.querySelector('.menu-toggle').onclick=e=>{const n=document.querySelector('.nav');n.classList.toggle('open');e.currentTarget.setAttribute('aria-expanded',n.classList.contains('open'))};
document.querySelectorAll('.nav a').forEach(a=>a.onclick=()=>document.querySelector('.nav').classList.remove('open'));
document.getElementById('year').textContent=new Date().getFullYear();
render();renderCart();
