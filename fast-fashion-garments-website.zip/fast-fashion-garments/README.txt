FAST FASHION GARMENTS — WEBSITE

Files:
- index.html — website structure
- style.css — responsive styling
- script.js — filters, search, cart, WhatsApp order link
- assets/website-design-reference.png — generated visual reference used for the fashion imagery

HOW TO USE
1. Keep the folder structure intact.
2. Open index.html in a browser, or upload the entire folder to a web host.
3. Replace the generated reference image in assets/ with your own product/fashion photos if desired.
4. Update social links in index.html where the # placeholders appear.

CONTACT DETAILS INCLUDED
Phone: +91 9931330223
Email: fastfashionexclusives@gmail.com
WhatsApp: +91 9931330223
